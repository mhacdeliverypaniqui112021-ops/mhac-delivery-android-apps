MHAC DELIVERY - 3 Android Apps

This project wraps the locked MHAC DELIVERY web apps without modifying the website.
Admin: https://mhacdelivery.devs.surf/admin.html
Customer: https://mhacdelivery.devs.surf/customer.html
Rider: https://mhacdelivery.devs.surf/rider.html

Includes: MHAC logo splash, WebView JavaScript/DOM storage/cookies, Google-login redirect handling, and back navigation.
