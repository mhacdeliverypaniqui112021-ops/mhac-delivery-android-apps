MHAC Android 3-app splash fix.
Uses one native launch-window logo only, then hands directly to the locked website.
Admin, Customer, and Rider URLs/features are unchanged.
