package com.mhacdelivery.customer;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  private WebView web;
  private FrameLayout root;
  private LinearLayout splash;
  private boolean opened = false;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);

    // Show the MHAC logo FIRST, before WebView is even created.
    splash = new LinearLayout(this);
    splash.setOrientation(LinearLayout.VERTICAL);
    splash.setGravity(Gravity.CENTER);
    splash.setBackgroundColor(Color.WHITE);

    ImageView logo = new ImageView(this);
    logo.setImageResource(R.drawable.mhac_logo);
    logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

    int logoSize = (int)(180 * getResources().getDisplayMetrics().density);
    splash.addView(logo, new LinearLayout.LayoutParams(logoSize, logoSize));

    setContentView(splash);

    // Give Android time to render the logo before WebView initialization.
    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
      @Override public void run() {
        openWebsite();
      }
    }, 900);
  }

  private void openWebsite() {
    if (opened) return;
    opened = true;

    root = new FrameLayout(this);

    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setSupportZoom(false);
    s.setBuiltInZoomControls(false);
    s.setDisplayZoomControls(false);
    s.setSupportMultipleWindows(false);
    s.setJavaScriptCanOpenWindowsAutomatically(true);
    s.setLoadsImagesAutomatically(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

    CookieManager cookies = CookieManager.getInstance();
    cookies.setAcceptCookie(true);
    cookies.setAcceptThirdPartyCookies(web, true);

    web.setBackgroundColor(Color.WHITE);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return false;
      }

      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return false;
      }

      @Override public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        CookieManager.getInstance().flush();
      }

      @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        super.onReceivedError(view, request, error);
      }
    });
    web.setWebChromeClient(new WebChromeClient());

    root.addView(web, new FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    ));
    setContentView(root);

    web.loadUrl("https://mhacdelivery.devs.surf/customer.html");
  }

  @Override protected void onResume() {
    super.onResume();
    CookieManager.getInstance().flush();
  }

  @Override protected void onDestroy() {
    if (web != null) {
      web.stopLoading();
      web.setWebChromeClient(null);
      web.setWebViewClient(null);
      web.destroy();
      web = null;
    }
    super.onDestroy();
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }
}
