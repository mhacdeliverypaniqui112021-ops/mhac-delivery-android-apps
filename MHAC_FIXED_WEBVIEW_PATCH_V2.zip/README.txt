MHAC DELIVERY — 3 ANDROID APPS

Native WebView wrapper V2.
Modules:
- admin -> https://mhacdelivery.devs.surf/admin.html
- customer -> https://mhacdelivery.devs.surf/customer.html
- rider -> https://mhacdelivery.devs.surf/rider.html

The website remains the locked source of UI, Firebase logic, and business features.
The V2 native wrapper adds popup-window support for Google authentication without modifying the website.
