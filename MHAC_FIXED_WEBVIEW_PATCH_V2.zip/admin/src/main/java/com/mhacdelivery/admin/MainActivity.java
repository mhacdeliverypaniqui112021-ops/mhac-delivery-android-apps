package com.mhacdelivery.admin;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private FrameLayout root;
    private WebView web;
    private WebView popup;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean firstLoad = true;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        configureWebView(web, false);
        web.loadUrl("https://mhacdelivery.devs.surf/admin.html");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView(WebView view, boolean isPopup) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        // Firebase Google sign-in in the locked website is popup-first.
        // Allow a real WebView child window so it can complete the OAuth popup
        // instead of falling back to signInWithRedirect (which causes the
        // storage-partitioned "missing initial state" screen in WebView).
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(view, true);

        view.setBackgroundColor(Color.WHITE);
        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                CookieManager.getInstance().flush();
                if (!isPopup) firstLoad = false;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest request,
                                        WebResourceError error) {
                super.onReceivedError(v, request, error);
                if (!isPopup && firstLoad && request.isForMainFrame()) {
                    handler.postDelayed(() -> {
                        if (web != null) web.reload();
                    }, 1200);
                }
            }

            @Override
            public void onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                if (isPopup) {
                    closePopup();
                } else {
                    firstLoad = true;
                    if (web != null) web.reload();
                }
                // We handled the renderer loss.
                super.onRenderProcessGone(v, detail);
            }
        });

        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView parent, boolean isDialog,
                                          boolean isUserGesture, android.os.Message resultMsg) {
                if (popup != null) closePopup();

                popup = new WebView(MainActivity.this);
                configureWebView(popup, true);
                popup.setBackgroundColor(Color.WHITE);

                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT);
                root.addView(popup, lp);
                popup.bringToFront();

                WebView.WebViewTransport transport =
                        (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public void onCloseWindow(WebView window) {
                if (window == popup) closePopup();
                else super.onCloseWindow(window);
            }
        });
    }

    private void closePopup() {
        if (popup == null) return;
        try {
            popup.stopLoading();
            popup.setWebChromeClient(null);
            popup.setWebViewClient(null);
            root.removeView(popup);
            popup.destroy();
        } catch (Exception ignored) {
        }
        popup = null;
        if (web != null) web.bringToFront();
    }

    @Override
    public void onBackPressed() {
        if (popup != null) {
            closePopup();
            return;
        }
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        closePopup();
        if (web != null) {
            web.stopLoading();
            web.setWebChromeClient(null);
            web.setWebViewClient(null);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
