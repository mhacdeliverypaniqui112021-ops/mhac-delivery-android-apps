# MHAC DELIVERY — Native Android All-in-One

One APK containing the three MHAC roles:
- ADMIN -> https://mhacdelivery.devs.surf/admin.html
- RIDER -> https://mhacdelivery.devs.surf/rider.html
- CUSTOMER -> https://mhacdelivery.devs.surf/customer.html

The locked website remains the application. This Android project does not copy or modify its UI, Firebase, Google login, orders, chat, menu, checkout, or rider flow.

The native launcher shows a simple MHAC welcome screen, then role selection. Each role is opened in the normal Android browser so Google sign-in and session storage remain browser-native, avoiding the WebView OAuth/sessionStorage problem.

This project produces ONE APK artifact.
