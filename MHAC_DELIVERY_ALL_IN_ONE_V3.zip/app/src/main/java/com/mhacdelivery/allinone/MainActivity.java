package com.mhacdelivery.allinone;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String ADMIN = "https://mhacdelivery.devs.surf/admin.html";
    private static final String CUSTOMER = "https://mhacdelivery.devs.surf/customer.html";
    private static final String RIDER = "https://mhacdelivery.devs.surf/rider.html";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showWelcome();
    }

    private void showWelcome() {
        LinearLayout box = base();
        TextView title = text("MHAC DELIVERY", 28);
        TextView sub = text("ADMIN • RIDER • CUSTOMER", 16);
        Button cont = button("CONTINUE");
        box.addView(title);
        box.addView(sub);
        box.addView(cont);
        cont.setOnClickListener(v -> showRoles());
        setContentView(box);
    }

    private void showRoles() {
        LinearLayout box = base();
        box.addView(text("MHAC DELIVERY", 26));
        box.addView(text("Select app", 18));
        Button admin = button("ADMIN");
        Button rider = button("RIDER");
        Button customer = button("CUSTOMER");
        box.addView(admin); box.addView(rider); box.addView(customer);
        admin.setOnClickListener(v -> open(ADMIN));
        rider.setOnClickListener(v -> open(RIDER));
        customer.setOnClickListener(v -> open(CUSTOMER));
        setContentView(box);
    }

    private void open(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private LinearLayout base() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(40, 40, 40, 40);
        l.setBackgroundColor(0xFFFFFFFF);
        return l;
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setGravity(Gravity.CENTER);
        t.setTextColor(0xFF111111);
        t.setPadding(0, 12, 0, 12);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(16);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 10, 0, 10);
        b.setLayoutParams(p);
        return b;
    }
}
