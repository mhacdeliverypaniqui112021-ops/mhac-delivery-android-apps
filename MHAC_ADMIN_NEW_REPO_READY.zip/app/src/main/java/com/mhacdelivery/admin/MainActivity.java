package com.mhacdelivery.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String URL = "https://mhacdelivery.devs.surf/admin.html";
    private final Handler handler = new Handler();
    private FrameLayout root;
    private WebView web;
    private View overlay;
    private boolean committed = false;
    private boolean failed = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
        showLogo("MHAC DELIVERY");
        handler.postDelayed(this::createWebView, 900);
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.BLACK); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setPadding(20, 10, 20, 10);
        return t;
    }

    private void showLogo(String caption) {
        removeOverlay();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(logo, new LinearLayout.LayoutParams(250,250));
        box.addView(text(caption,20));
        overlay = box;
        root.addView(overlay, new FrameLayout.LayoutParams(-1,-1));
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void createWebView() {
        if (web != null) return;
        removeOverlay();

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_OFF);
        }

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }

            @Override public void onPageCommitVisible(WebView v, String u) {
                committed = true;
                checkContent();
            }

            @Override public void onPageFinished(WebView v, String u) {
                CookieManager.getInstance().flush();
                checkContent();
            }

            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r == null || r.isForMainFrame()) {
                    failed = true;
                    showError("Hindi ma-load ang Admin.");
                }
            }

            @Override public void onReceivedError(WebView v, int c, String d, String u) {
                failed = true;
                showError("Hindi ma-load ang Admin.");
            }
        });

        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
        showLoading();
        web.loadUrl(URL);

        handler.postDelayed(() -> {
            if (!committed && !failed) showError("Matagal ang pag-load ng Admin.");
            else if (!failed) checkContent();
        }, 15000);
    }

    private void showLoading() {
        removeOverlay();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(logo, new LinearLayout.LayoutParams(170,170));
        box.addView(text("Loading MHAC DELIVERY ADMIN...",16));
        overlay = box;
        root.addView(overlay, new FrameLayout.LayoutParams(-1,-1));
    }

    private void checkContent() {
        if (web == null || failed) return;
        handler.postDelayed(() -> web.evaluateJavascript(
            "(function(){return ((document.body&&document.body.innerText)||'').trim().length;})()",
            value -> {
                if (value != null && !value.equals("0") && !value.equals("null")) removeOverlay();
                else showError("Walang lumabas na Admin page.");
            }), 800);
    }

    private void showError(String msg) {
        removeOverlay();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(30,30,30,30);
        box.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(logo, new LinearLayout.LayoutParams(150,150));
        box.addView(text(msg + "\n\nCheck internet, then tap RETRY.",16));
        Button retry = new Button(this);
        retry.setText("RETRY");
        retry.setOnClickListener(v -> retry());
        box.addView(retry, new LinearLayout.LayoutParams(-2,-2));
        overlay = box;
        root.addView(overlay, new FrameLayout.LayoutParams(-1,-1));
    }

    private void retry() {
        committed = false; failed = false;
        showLoading();
        if (web == null) createWebView();
        else web.reload();
    }

    private void removeOverlay() {
        if (overlay != null) {
            root.removeView(overlay);
            overlay = null;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        CookieManager.getInstance().flush();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (web != null) { web.stopLoading(); web.destroy(); web = null; }
        super.onDestroy();
    }
}
