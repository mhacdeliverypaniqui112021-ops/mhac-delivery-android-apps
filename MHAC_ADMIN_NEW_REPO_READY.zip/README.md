# MHAC DELIVERY ADMIN Android
Fresh Admin-only Android wrapper for the locked MHAC DELIVERY website.
URL: https://mhacdelivery.devs.surf/admin.html
The website itself is not modified.
