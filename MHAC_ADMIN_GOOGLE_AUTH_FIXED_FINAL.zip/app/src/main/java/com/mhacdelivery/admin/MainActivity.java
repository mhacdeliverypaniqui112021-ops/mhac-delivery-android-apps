package com.mhacdelivery.admin;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.browser.customtabs.CustomTabsIntent;

public class MainActivity extends Activity {
    private static final String ADMIN_URL = "https://mhacdelivery.devs.surf/admin.html";
    private static final int SPLASH_MS = 1800;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        showSplash();

        new Handler(Looper.getMainLooper()).postDelayed(() -> openAdminInBrowser(), SPLASH_MS);
    }

    private void showSplash() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(24, 24, 24, 24);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.mhacdelivery.admin.R.drawable.mhac_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

        int logoSize = (int) (190 * getResources().getDisplayMetrics().density);
        root.addView(logo, new LinearLayout.LayoutParams(logoSize, logoSize));

        TextView title = new TextView(this);
        title.setText("MHAC DELIVERY ADMIN");
        title.setTextColor(Color.BLACK);
        title.setTextSize(23);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = 14;
        root.addView(title, titleLp);

        TextView loading = new TextView(this);
        loading.setText("Loading Admin...");
        loading.setTextColor(Color.DKGRAY);
        loading.setTextSize(15);
        loading.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams loadingLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        loadingLp.topMargin = 8;
        root.addView(loading, loadingLp);

        ProgressBar bar = new ProgressBar(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                44, 44);
        barLp.gravity = Gravity.CENTER_HORIZONTAL;
        barLp.topMargin = 16;
        root.addView(bar, barLp);

        setContentView(root);
    }

    private void openAdminInBrowser() {
        try {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setShowTitle(true);
            builder.setToolbarColor(Color.WHITE);
            builder.setColorScheme(CustomTabsIntent.COLOR_SCHEME_LIGHT);

            CustomTabsIntent tabs = builder.build();
            tabs.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            tabs.launchUrl(this, Uri.parse(ADMIN_URL));
        } catch (Exception e) {
            // Guaranteed fallback: use the normal browser.
            Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(ADMIN_URL));
            startActivity(browser);
        }

        // The Android activity is only the launcher/splash. The actual Admin
        // session runs in Chrome/Custom Tabs, where Firebase sessionStorage
        // and Google OAuth redirect state are supported.
        finish();
    }

    @Override
    public void onBackPressed() {
        // The Admin page is owned by Chrome/Custom Tabs. Let Android close
        // this launcher activity rather than trying to control WebView history.
        super.onBackPressed();
    }
}
