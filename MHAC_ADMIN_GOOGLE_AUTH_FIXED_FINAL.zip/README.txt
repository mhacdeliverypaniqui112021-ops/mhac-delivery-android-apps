# MHAC DELIVERY ADMIN — FINAL GOOGLE AUTH FIX

This is the Admin-only Android project for MHAC DELIVERY.

## What was fixed

The previous APK used an Android WebView for the Firebase web app. When Google popup failed,
the website fell back to `signInWithRedirect()`. In the Android WebView this could lose the
Firebase redirect/session state and produce:

"Unable to process request due to missing initial state."

This build removes that WebView auth problem by launching the existing Admin web app in an
Android Chrome Custom Tab. Firebase/Google OAuth therefore runs in the normal browser storage
environment.

## Preserved

- Existing Admin website URL:
  https://mhacdelivery.devs.surf/admin.html
- Existing Admin web UI and Firebase project
- Existing MHAC logo
- Native MHAC splash before opening Admin
- Portrait orientation
- No changes to Firestore/menu/order business logic

## Build

GitHub Actions builds:
`app/build/outputs/apk/debug/app-debug.apk`

Workflow:
`.github/workflows/build-apk.yml`

## Important

Do NOT keep the old WebView MainActivity for this Admin APK. Replace the old repository contents
with this project before building the new APK.
