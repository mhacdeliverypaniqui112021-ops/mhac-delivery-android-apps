# MHAC DELIVERY Native APKs V2

This is the corrected native APK package for ALL THREE MHAC apps:

- ADMIN -> https://mhacdelivery.devs.surf/admin.html
- CUSTOMER -> https://mhacdelivery.devs.surf/customer.html
- RIDER -> https://mhacdelivery.devs.surf/rider.html

The three Android apps are in ONE repository/build project, with separate APK artifacts.

IMPORTANT:
- The locked website/source is the actual application.
- These Android projects are only thin launchers.
- Do not copy or rewrite the website UI into the APK.
- Do not change Firebase, Google login, orders, chat, menu, checkout, rider flow, or admin dashboard.
- The native APK does NOT add a custom loading screen.
- Admin is included again because it is an essential part of the MHAC system.

Why the APK opens the locked site in the normal Android browser:
This avoids embedding Google sign-in inside a WebView and helps prevent the sessionStorage / "missing initial state" problem seen in the previous Admin APK.
