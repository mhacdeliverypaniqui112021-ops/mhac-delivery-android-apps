# MHAC DELIVERY ADMIN – Google Login Compatibility Fix

Admin-only Android WebView build. The locked website URL is unchanged.

Changes in this build:
- Keeps the native WebView user-agent (does not spoof Chrome).
- Enables DOM storage/database/form storage.
- Accepts cookies and third-party cookies.
- Keeps a non-blank loading/error screen.
- Recovers from a WebView renderer crash.
- Admin package versionCode 2 / versionName 1.1.

Website URL: https://mhacdelivery.devs.surf/admin.html

Important: this is an Android-only compatibility test. If Firebase still reports “missing initial state / sessionStorage” during Google sign-in, that is a limitation of the locked web auth flow inside Android WebView; the next solution would require native/external OAuth handling or a website auth change.
