package com.mhacdelivery.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String URL = "https://mhacdelivery.devs.surf/admin.html";
    private final Handler handler = new Handler();
    private FrameLayout root;
    private WebView web;
    private LinearLayout splash, error;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        makeUi();
        load();
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setGravity(Gravity.CENTER); return t;
    }

    private void makeUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        splash.addView(logo, new LinearLayout.LayoutParams(170,170));
        TextView title = text("MHAC DELIVERY ADMIN",20);
        title.setTextColor(Color.BLACK); title.setTypeface(null,1);
        splash.addView(title,new LinearLayout.LayoutParams(-1,55));
        splash.addView(text("Loading…",15),new LinearLayout.LayoutParams(-1,45));
        root.addView(splash,new FrameLayout.LayoutParams(-1,-1));

        error = new LinearLayout(this);
        error.setOrientation(LinearLayout.VERTICAL); error.setGravity(Gravity.CENTER);
        error.addView(text("MHAC DELIVERY ADMIN",20),new LinearLayout.LayoutParams(-1,55));
        error.addView(text("Hindi ma-load ang Admin app.",16),new LinearLayout.LayoutParams(-1,55));
        error.addView(text("Check internet connection.",14),new LinearLayout.LayoutParams(-1,50));
        Button retry = new Button(this);
        retry.setText("RETRY");
        retry.setOnClickListener(v -> { error.setVisibility(View.GONE); splash.setVisibility(View.VISIBLE); load(); });
        error.addView(retry,new LinearLayout.LayoutParams(180,60));
        error.setVisibility(View.GONE);
        root.addView(error,new FrameLayout.LayoutParams(-1,-1));
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void load() {
        if (web != null) { root.removeView(web); web.destroy(); }
        splash.setVisibility(View.VISIBLE); error.setVisibility(View.GONE);

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setSupportZoom(false);

        CookieManager cm=CookieManager.getInstance();
        cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(web,true);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView v,String u){ return false; }
            @Override public void onPageCommitVisible(WebView v,String u){ showWeb(); }
            @Override public void onPageFinished(WebView v,String u){ CookieManager.getInstance().flush(); showWeb(); }
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){
                if(r.isForMainFrame()) showError();
            }
            @Override public void onReceivedError(WebView v,int c,String d,String u){ showError(); }
        });

        root.addView(web,0,new FrameLayout.LayoutParams(-1,-1));
        web.loadUrl(URL);

        // Safety: after 12 seconds, never leave the user staring at a blank overlay.
        handler.postDelayed(() -> {
            if (web != null && web.getVisibility() != View.VISIBLE) showWeb();
        },12000);
    }

    private void showWeb(){ handler.post(() -> {
        web.setVisibility(View.VISIBLE); splash.setVisibility(View.GONE); error.setVisibility(View.GONE);
    }); }

    private void showError(){ handler.post(() -> {
        web.setVisibility(View.GONE); splash.setVisibility(View.GONE); error.setVisibility(View.VISIBLE);
    }); }

    @Override protected void onResume(){ super.onResume(); CookieManager.getInstance().flush(); }
    @Override public void onBackPressed(){
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(web!=null){web.stopLoading();web.destroy();}
        super.onDestroy();
    }
}
