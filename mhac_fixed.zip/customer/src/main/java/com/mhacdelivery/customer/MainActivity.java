package com.mhacdelivery.customer;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

public class MainActivity extends AppCompatActivity {
  private WebView web;
  private volatile boolean pageLoaded = false;

  @Override protected void onCreate(Bundle b) {
    SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
    splashScreen.setKeepOnScreenCondition(new SplashScreen.KeepOnScreenCondition() {
      @Override public boolean shouldKeepOnScreen() {
        return !pageLoaded;
      }
    });

    super.onCreate(b);

    // Safety timeout: never leave the native splash stuck forever.
    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
      @Override public void run() { pageLoaded = true; }
    }, 8000);

    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setSupportZoom(false);
    s.setBuiltInZoomControls(false);
    s.setDisplayZoomControls(false);
    s.setSupportMultipleWindows(false);
    s.setJavaScriptCanOpenWindowsAutomatically(true);
    s.setLoadsImagesAutomatically(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

    CookieManager cookies = CookieManager.getInstance();
    cookies.setAcceptCookie(true);
    cookies.setAcceptThirdPartyCookies(web, true);

    web.setBackgroundColor(Color.WHITE);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return false;
      }

      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return false;
      }

      @Override public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        pageLoaded = true;
        CookieManager.getInstance().flush();
      }
    });
    web.setWebChromeClient(new WebChromeClient());

    setContentView(web);
    web.loadUrl("https://mhacdelivery.devs.surf/customer.html");
  }

  @Override protected void onResume() {
    super.onResume();
    CookieManager.getInstance().flush();
  }

  @Override protected void onDestroy() {
    if (web != null) {
      web.stopLoading();
      web.setWebChromeClient(null);
      web.setWebViewClient(null);
      web.destroy();
      web = null;
    }
    super.onDestroy();
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }
}
