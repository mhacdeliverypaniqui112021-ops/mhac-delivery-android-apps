package com.mhacdelivery.customer;

import android.app.*; import android.os.*; import android.webkit.*; import android.graphics.Color; import android.view.*; import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  private WebView web;
  @Override protected void onCreate(Bundle b) { super.onCreate(b); web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setSupportZoom(false);
    CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
    web.setBackgroundColor(Color.WHITE); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
    web.loadUrl("https://mhacdelivery.devs.surf/customer.html"); }
  @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
