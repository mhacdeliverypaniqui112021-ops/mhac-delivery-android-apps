MHAC DELIVERY — 3 ANDROID APPS

Modules:
- admin   -> https://mhacdelivery.devs.surf/admin.html
- customer -> https://mhacdelivery.devs.surf/customer.html
- rider -> https://mhacdelivery.devs.surf/rider.html

The apps are WebView wrappers. The locked MHAC DELIVERY website/backend remains the source of the existing features. The Android project does not modify the website.

Build with Android Studio / Gradle. Outputs:
admin/build/outputs/apk/debug/admin-debug.apk
customer/build/outputs/apk/debug/customer-debug.apk
rider/build/outputs/apk/debug/rider-debug.apk


Added native MHAC logo splash on app startup while preserving the Google Login WebView fix.
