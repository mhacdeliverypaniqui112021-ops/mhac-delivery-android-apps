package com.mhacdelivery.rider;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  private WebView web;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    FrameLayout root = new FrameLayout(this);

        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(Color.WHITE);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int logoSize = (int)(180 * getResources().getDisplayMetrics().density);
        splash.addView(logo, new LinearLayout.LayoutParams(logoSize, logoSize));

        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);

        splash.postDelayed(() -> {
            splash.animate()
                    .alpha(0f)
                    .setDuration(250)
                    .withEndAction(() -> root.removeView(splash))
                    .start();
        }, 1200);

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setSupportZoom(false);
    s.setSupportMultipleWindows(false);
    s.setJavaScriptCanOpenWindowsAutomatically(true);
    s.setLoadsImagesAutomatically(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

    CookieManager cookies = CookieManager.getInstance();
    cookies.setAcceptCookie(true);
    cookies.setAcceptThirdPartyCookies(web, true);

    web.setBackgroundColor(Color.WHITE);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return false;
      }
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient());

    web.loadUrl("https://mhacdelivery.devs.surf/rider.html");
  }

  @Override protected void onResume() {
    super.onResume();
    CookieManager.getInstance().flush();
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }
}
