package com.mhacdelivery.admin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String URL = "https://mhacdelivery.devs.surf/admin.html";
    private final Handler handler = new Handler();
    private FrameLayout root;
    private WebView web;
    private WebView popup;
    private LinearLayout splash, error;
    private long loadStarted;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        makeUi();
        load();
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.DKGRAY);
        t.setGravity(Gravity.CENTER); return t;
    }

    private void makeUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        splash.addView(logo, new LinearLayout.LayoutParams(190,190));
        TextView title = text("MHAC DELIVERY ADMIN",20);
        title.setTextColor(Color.BLACK); title.setTypeface(null,1);
        splash.addView(title,new LinearLayout.LayoutParams(-1,55));
        splash.addView(text("Loading…",15),new LinearLayout.LayoutParams(-1,45));
        root.addView(splash,new FrameLayout.LayoutParams(-1,-1));

        error = new LinearLayout(this);
        error.setOrientation(LinearLayout.VERTICAL); error.setGravity(Gravity.CENTER);
        ImageView eLogo = new ImageView(this);
        eLogo.setImageResource(R.drawable.mhac_logo);
        eLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        error.addView(eLogo,new LinearLayout.LayoutParams(120,120));
        error.addView(text("Hindi ma-load ang Admin page.",20),new LinearLayout.LayoutParams(-1,55));
        error.addView(text("Check internet, then tap RETRY.",16),new LinearLayout.LayoutParams(-1,50));
        Button retry = new Button(this);
        retry.setText("RETRY");
        retry.setOnClickListener(v -> { closePopup(); error.setVisibility(View.GONE); splash.setVisibility(View.VISIBLE); load(); });
        error.addView(retry,new LinearLayout.LayoutParams(180,60));
        error.setVisibility(View.GONE);
        root.addView(error,new FrameLayout.LayoutParams(-1,-1));
    }

    @SuppressLint("SetJavaScriptEnabled")
    private WebView makeWebView() {
        WebView v = new WebView(this);
        v.setBackgroundColor(Color.WHITE);
        v.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        // IMPORTANT: Firebase signInWithPopup() uses window.open(). Android WebView
        // ignores new windows unless multi-window support is explicitly enabled.
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(v,true);
        return v;
    }

    private void applyMainClient(WebView v) {
        v.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return false; }
            @Override public void onPageCommitVisible(WebView view, String url) { showWeb(); }
            @Override public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
                showWeb();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError errorObj) {
                if (request.isForMainFrame() && loadStarted > 0 && System.currentTimeMillis() - loadStarted > 1500) showError();
            }
            @Override public void onReceivedError(WebView view, int code, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.startsWith("https://mhacdelivery.devs.surf/")) showError();
            }
        });
    }

    private void applyPopupClient(WebView v) {
        v.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return false; }
            @Override public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
            }
        });
    }

    private WebChromeClient chromeClient() {
        return new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // Give Firebase's signInWithPopup() a real child WebView window.
                // This preserves the opener relationship instead of falling back
                // to signInWithRedirect(), which loses sessionStorage in embedded WebView.
                closePopup();
                popup = makeWebView();
                applyPopupClient(popup);
                popup.setWebChromeClient(new WebChromeClient() {
                    @Override public void onCloseWindow(WebView window) {
                        closePopup();
                    }
                });
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,-1);
                root.addView(popup, lp);
                popup.bringToFront();
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }

            @Override public void onCloseWindow(WebView window) {
                if (window == popup) closePopup();
            }
        };
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void load() {
        closePopup();
        if (web != null) {
            root.removeView(web);
            web.stopLoading();
            web.destroy();
            web = null;
        }
        splash.setVisibility(View.VISIBLE);
        error.setVisibility(View.GONE);

        web = makeWebView();
        applyMainClient(web);
        web.setWebChromeClient(chromeClient());
        root.addView(web,0,new FrameLayout.LayoutParams(-1,-1));
        loadStarted = System.currentTimeMillis();
        web.loadUrl(URL);

        // The splash is only a safety screen. Do not turn a slow Firebase/CDN
        // response into a false error too quickly.
        handler.postDelayed(() -> {
            if (web != null && splash.getVisibility() == View.VISIBLE && web.getProgress() >= 70) showWeb();
        }, 15000);
        handler.postDelayed(() -> {
            if (web != null && splash.getVisibility() == View.VISIBLE && web.getProgress() < 70) showError();
        }, 30000);
    }

    private void closePopup() {
        if (popup != null) {
            try { popup.stopLoading(); } catch (Exception ignored) {}
            root.removeView(popup);
            popup.destroy();
            popup = null;
        }
    }

    private void showWeb(){ handler.post(() -> {
        if (web == null) return;
        web.setVisibility(View.VISIBLE);
        splash.setVisibility(View.GONE);
        error.setVisibility(View.GONE);
    }); }

    private void showError(){ handler.post(() -> {
        if (web != null) web.setVisibility(View.GONE);
        closePopup();
        splash.setVisibility(View.GONE);
        error.setVisibility(View.VISIBLE);
    }); }

    @Override protected void onResume(){ super.onResume(); CookieManager.getInstance().flush(); }

    @Override public void onBackPressed(){
        if (popup != null) { closePopup(); return; }
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        closePopup();
        if(web!=null){web.stopLoading();web.destroy();web=null;}
        super.onDestroy();
    }
}
