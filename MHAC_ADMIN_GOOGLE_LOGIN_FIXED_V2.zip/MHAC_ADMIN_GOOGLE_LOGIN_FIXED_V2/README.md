# MHAC DELIVERY ADMIN — Google Login WebView Fix V2

This is an Android-only wrapper fix for the existing MHAC DELIVERY Admin web app.

Website URL is unchanged:
https://mhacdelivery.devs.surf/admin.html

## Main fix
The Admin web page already uses Firebase `signInWithPopup()` first and only falls back to `signInWithRedirect()` when the popup fails. Android WebView does not create/handle JavaScript popup windows unless multiple-window support is enabled. This build explicitly creates a child WebView for `window.open()` and preserves the opener relationship used by Firebase popup authentication.

This avoids the previous redirect fallback that produced the Firebase `missing initial state` error because redirect auth depends on browser storage surviving the redirect.

## Other stability fixes
- DOM storage enabled
- cookies + third-party cookies enabled
- native WebView user agent retained
- JavaScript enabled
- 30-second load timeout instead of an early false failure
- popup WebView can be closed with Android Back
- WebView renderer/page errors no longer leave a permanent splash
- versionCode 2 / versionName 2.0

## Locked scope
No Admin HTML/UI/business logic is bundled or modified here. The wrapper continues to load the existing Admin page.

Build environment used by the project:
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- compileSdk/targetSdk 35
