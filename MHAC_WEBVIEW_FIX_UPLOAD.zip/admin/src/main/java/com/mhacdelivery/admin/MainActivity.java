package com.mhacdelivery.admin;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private FrameLayout root;
    private LinearLayout splash;
    private boolean splashRemoved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // First screen: MHAC logo only.
        root = new FrameLayout(this);

        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(Color.WHITE);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mhac_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

        int logoSize = (int)(180 * getResources().getDisplayMetrics().density);
        splash.addView(logo, new LinearLayout.LayoutParams(logoSize, logoSize));

        root.addView(splash, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);

        // WebView is created after the logo screen is already visible.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                openWebsite();
            }
        }, 700);
    }

    private void openWebsite() {
        web = new WebView(this);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        // Use a Chrome-like Android UA. Some hosted sites behave differently for
        // embedded WebViews; this keeps the locked website's normal browser path.
        String ua = s.getUserAgentString();
        if (ua == null || ua.length() == 0) {
            ua = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 "
               + "(KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36";
        } else if (!ua.contains("Chrome/")) {
            ua = ua + " Chrome/140.0.0.0 Mobile Safari/537.36";
        }
        s.setUserAgentString(ua);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setBackgroundColor(Color.WHITE);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                super.onPageCommitVisible(view, url);
                // This fires when the page has actually produced visible content,
                // unlike relying only on onPageFinished.
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override public void run() { removeSplash(); }
                }, 150);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    // Don't leave a white screen forever if the main page itself fails.
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override public void run() { removeSplash(); }
                    }, 300);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient());

        root.addView(web, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        web.loadUrl("https://mhacdelivery.devs.surf/admin.html");

        // Safety fallback: never trap the user on the logo screen.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { removeSplash(); }
        }, 10000);
    }

    private void removeSplash() {
        if (splashRemoved) return;
        splashRemoved = true;
        if (splash != null) {
            splash.animate()
                .alpha(0f)
                .setDuration(180)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        if (root != null && splash != null) root.removeView(splash);
                    }
                }).start();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            web.setWebChromeClient(null);
            web.setWebViewClient(null);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
