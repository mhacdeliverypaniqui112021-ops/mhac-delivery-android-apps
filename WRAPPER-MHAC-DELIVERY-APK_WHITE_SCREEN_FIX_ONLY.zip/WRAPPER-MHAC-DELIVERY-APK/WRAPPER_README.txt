MHAC DELIVERY - GRADLE WRAPPER

This package includes a Gradle 8.7 wrapper launcher.
AGP 8.6.x requires Gradle 8.7 or newer.

Root commands:
  ./gradlew assembleDebug
  ./gradlew assembleAdmin
  ./gradlew assembleCustomer
  ./gradlew assembleRider

The first run downloads the official Gradle 8.7 binary distribution to the user's Gradle cache.
Internet access is required on the first build.
