# MHAC DELIVERY Admin APK

Independent Android WebView project.

Entry page:
https://mhacdeliverypaniqui112021-ops.github.io/mhacfooddelivery/admin.html

Keep this folder intact when uploading to GitHub. Do not flatten the files.
