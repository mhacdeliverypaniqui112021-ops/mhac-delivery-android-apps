@echo off
set APP_HOME=%~dp0
if "%APP_HOME:~-1%"=="\" set APP_HOME=%APP_HOME:~0,-1%
java -Dorg.gradle.appname=gradlew -classpath "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
