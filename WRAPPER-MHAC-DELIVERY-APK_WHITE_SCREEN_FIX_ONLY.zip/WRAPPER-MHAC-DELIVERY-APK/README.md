# MHAC DELIVERY APK V2 — CLEAN SOURCE

This repository contains THREE independent Android projects:

- `customer/` — MHAC Delivery Customer APK
- `admin/` — MHAC Delivery Admin APK
- `rider/` — MHAC Delivery Rider APK

IMPORTANT:
Upload the folders exactly as shown. Do NOT flatten their contents into the repository root.

Each project has its own:
- settings.gradle
- build.gradle
- app/build.gradle
- AndroidManifest.xml
- MainActivity.java
- res/values/styles.xml

The web app URLs remain the current MHAC DELIVERY pages; the existing UI and Firebase/web business logic are not replaced by this Android wrapper package.
