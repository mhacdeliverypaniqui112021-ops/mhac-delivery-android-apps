# MHAC DELIVERY Customer APK

Independent Android WebView project.

Entry page:
https://mhacdeliverypaniqui112021-ops.github.io/mhacfooddelivery/customer.html

Keep this folder intact when uploading to GitHub. Do not flatten the files.
